
const {Op} = require('sequelize')


const getAllRecomend = (req,res)=>{
 

    
}




module.exports={
    getAllRecomend,
    
}