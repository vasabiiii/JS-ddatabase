module.exports={
    development:{
        username: "admin",
        password: "root",
        database: "admin",
        host: "localhost",
        dialect: "postgres",
    },
    production:{

    },
};